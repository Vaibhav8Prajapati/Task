import React, { useEffect, useState } from 'react'
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css";
import Api from './Api';

export default function () {
  return (
    <>
      <div className='container'>
          <div className='header'></div>
          <div className='row filtter'>
            <div className='col-10'></div>
            <div className='col-2'><button>Clear</button></div>
          </div>
        <Api/>
      </div> 
    </>
  )
}
